<?php
require __DIR__ . '/lib/db.php';
require __DIR__ . '/lib/layout.php';

render_header('Statut DB — Cyber Dashboard');

echo "<h1>Statut base de données</h1>";
echo "<p class='lead'>Vérifie la connexion MySQL/MariaDB et la présence des tables.</p>";

try {
    $pdo = db();
    $v = $pdo->query("SELECT VERSION() AS v")->fetch()['v'] ?? '';
    echo "<div class='card'><div>Connexion: <span class='badge'>OK</span></div>";
    echo "<div class='muted' style='margin-top:8px;'>Version: <span class='badge'>" . h((string)$v) . "</span></div></div>";

    $tables = $pdo->query("SHOW TABLES")->fetchAll();
    $names = array_map(fn($r)=>array_values($r)[0], $tables);

    echo "<div class='card' style='margin-top:14px;'><h2 style='margin-top:0;'>Tables détectées</h2>";
    if (!$names) {
        echo "<div class='muted'>Aucune table. Importez <span class='badge'>db/schema_mysql.sql</span> via phpMyAdmin (onglet Importer).</div>";
    } else {
        echo "<ul>";
        foreach ($names as $n) echo "<li><span class='badge'>" . h((string)$n) . "</span></li>";
        echo "</ul>";
    }
    echo "</div>";

} catch (Throwable $e) {
    echo "<div class='card'><div>Connexion: <span class='badge badge--g5'>ECHEC</span></div>";
    echo "<div class='muted' style='margin-top:10px;'>Erreur: " . h($e->getMessage()) . "</div>";
    echo "<div class='muted' style='margin-top:10px;'>Vérifiez <span class='badge'>web/config/config.php</span> et que MySQL/MariaDB est démarré.</div>";
    echo "</div>";
}

render_footer();
