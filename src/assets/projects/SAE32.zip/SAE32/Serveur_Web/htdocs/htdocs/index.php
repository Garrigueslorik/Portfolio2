<?php
require __DIR__ . '/lib/db.php';
require __DIR__ . '/lib/layout.php';

$pdo = db();

$kpi_scans = (int)$pdo->query("SELECT COUNT(*) AS c FROM scan_sessions")->fetch()['c'];
$kpi_failles = (int)$pdo->query("SELECT COUNT(*) AS c FROM failles")->fetch()['c'];
$kpi_max_g = (int)$pdo->query("SELECT COALESCE(MAX(gravite), 0) AS m FROM failles")->fetch()['m'];

$stmt = $pdo->prepare("
    SELECT
      s.id,
      s.started_at,
      COALESCE(COUNT(f.id), 0) AS nb_failles,
      COALESCE(MAX(f.gravite), 0) AS max_gravite
    FROM scan_sessions s
    LEFT JOIN failles f ON f.scan_id = s.id
    GROUP BY s.id
    ORDER BY s.started_at DESC
    LIMIT 25
");
$stmt->execute();
$scans = $stmt->fetchAll();

render_header('Accueil — Cyber Dashboard');
?>
  <h1>Tableau de bord</h1>
  <p class="lead">Visualisation des failles stockées en base de données (MySQL/MariaDB).</p>

  <div class="grid cols-3">
    <div class="card kpi">
      <div>
        <div class="label">Scans</div>
        <div class="value"><?= h((string)$kpi_scans) ?></div>
      </div>
      <div class="pill">sessions</div>
    </div>
    <div class="card kpi">
      <div>
        <div class="label">Failles</div>
        <div class="value"><?= h((string)$kpi_failles) ?></div>
      </div>
      <div class="pill">enregistrements</div>
    </div>
    <div class="card kpi">
      <div>
        <div class="label">Gravité max</div>
        <div class="value"><?= h((string)$kpi_max_g) ?></div>
      </div>
      <div class="pill">score</div>
    </div>
  </div>

  <div class="card" style="margin-top: 14px;">
    <div style="display:flex; align-items:baseline; justify-content:space-between; gap:12px; flex-wrap:wrap;">
      <h2 style="margin:0;">Scans récents</h2>
      <div class="muted">Cliquez sur un scan pour voir le détail des failles.</div>
    </div>

    <div style="overflow:auto; margin-top: 10px;">
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Date</th>
            <th>Nb failles</th>
            <th>Gravité max</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php if (!$scans): ?>
            <tr><td colspan="5" class="muted">Aucun scan pour le moment. Envoyez des failles via l'API <span class="badge">/api/failles/</span>.</td></tr>
          <?php else: ?>
            <?php foreach ($scans as $s): ?>
              <tr>
                <td class="mono"><?= h((string)$s['id']) ?></td>
                <td class="mono"><?= h((string)$s['started_at']) ?></td>
                <td class="mono"><?= h((string)$s['nb_failles']) ?></td>
                <td class="mono">
                  <?php
                    $g = (int)$s['max_gravite'];
                    $cls = $g >= 5 ? "badge--g5" : ($g >= 4 ? "badge--g4" : "badge--g3");
                  ?>
                  <span class="badge <?= $cls ?>"><?= h((string)$g) ?></span>
                </td>
                <td><a href="/scan.php?id=<?= urlencode((string)$s['id']) ?>">Voir</a></td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <div class="grid cols-2" style="margin-top: 14px;">
    <div class="card">
      <h2 style="margin-top:0;">API (JSON)</h2>
      <p class="muted">Endpoints:</p>
      <ul>
        <li><span class="badge">POST /api/failles/</span> — insertion d'une session + failles</li>
        <li><span class="badge">GET /api/scans/</span> — liste des sessions</li>
        <li><span class="badge">GET /api/failles/</span> — liste filtrable (scan_id, ip, type, min_gravite, q)</li>
      </ul>
    </div>
    <div class="card">
      <h2 style="margin-top:0;">phpMyAdmin</h2>
      <p class="muted">Importez le schéma <span class="badge">db/schema_mysql.sql</span> via phpMyAdmin, puis vérifiez sur <a href="/status.php">/status.php</a>.</p>
    </div>
  </div>
<?php render_footer(); ?>
