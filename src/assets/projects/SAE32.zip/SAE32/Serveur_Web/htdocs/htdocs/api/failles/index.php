<?php
require __DIR__ . '/../../lib/db.php';

$pdo = db();
$cfg = app_config();

// POST: insertion d'une session + failles (JSON = liste)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_method('POST');

    $data = read_json_body(true); // liste JSON

    $pdo->beginTransaction();
    try {
        $insScan = $pdo->prepare("INSERT INTO scan_sessions (source, base_ip, note) VALUES (:source, :base_ip, :note)");
        $source = $_SERVER['HTTP_X_SOURCE'] ?? 'java-scanner';
        $base_ip = $_SERVER['HTTP_X_BASE_IP'] ?? null;
        $note = $_SERVER['HTTP_X_NOTE'] ?? null;

        $insScan->execute([
            ':source' => $source,
            ':base_ip' => $base_ip,
            ':note' => $note,
        ]);

        $scanId = (int)$pdo->lastInsertId();

        $ins = $pdo->prepare("
            INSERT INTO failles (scan_id, ip, type, description, gravite)
            VALUES (:scan_id, :ip, :type, :description, :gravite)
        ");

        $inserted = 0;
        $errors = [];

        foreach ($data as $i => $row) {
            if (!is_array($row)) {
                $errors[] = ['index' => $i, 'error' => 'objet attendu'];
                continue;
            }

            $ip = isset($row['ip']) ? trim((string)$row['ip']) : '';
            $type = isset($row['type']) ? trim((string)$row['type']) : '';
            $description = isset($row['description']) ? (string)$row['description'] : '';
            $gravite = array_key_exists('gravite', $row) ? (int)$row['gravite'] : null;

            if ($ip === '' || $type === '' || $description === '' || $gravite === null) {
                $errors[] = ['index' => $i, 'error' => 'champs requis: ip, type, description, gravite'];
                continue;
            }

            $ins->execute([
                ':scan_id' => $scanId,
                ':ip' => $ip,
                ':type' => $type,
                ':description' => $description,
                ':gravite' => $gravite,
            ]);

            $inserted++;
        }

        $pdo->commit();
        json_response(['scan_id' => $scanId, 'inserted' => $inserted, 'errors' => $errors], 201);

    } catch (Throwable $e) {
        $pdo->rollBack();
        json_response(['error' => 'Erreur serveur', 'detail' => $e->getMessage()], 500);
    }
}

// GET: liste filtrable
require_method('GET');

$scan_id = int_param('scan_id');
$ip = str_param('ip');
$type = str_param('type');
$min_g = int_param('min_gravite');
$q = str_param('q');

$limit = int_param('limit', (int)($cfg['default_limit'] ?? 200));
if ($limit < 1) $limit = (int)($cfg['default_limit'] ?? 200);
if ($limit > 5000) $limit = 5000;

$offset = int_param('offset', 0);
if ($offset < 0) $offset = 0;

$where = [];
$params = [];

if ($scan_id !== null) { $where[] = "scan_id = :scan_id"; $params[':scan_id'] = $scan_id; }
if ($ip) { $where[] = "ip = :ip"; $params[':ip'] = $ip; }
if ($type) { $where[] = "type = :type"; $params[':type'] = $type; }
if ($min_g !== null) { $where[] = "gravite >= :min_g"; $params[':min_g'] = $min_g; }
if ($q) { $where[] = "(description LIKE :q OR ip LIKE :q OR type LIKE :q)"; $params[':q'] = '%' . $q . '%'; }

$sql = "SELECT id, scan_id, ip, type, description, gravite, created_at FROM failles";
if ($where) $sql .= " WHERE " . implode(" AND ", $where);
$sql .= " ORDER BY created_at DESC LIMIT " . (int)$limit . " OFFSET " . (int)$offset;

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

json_response([
    'items' => $rows,
    'limit' => $limit,
    'offset' => $offset,
    'filters' => [
        'scan_id' => $scan_id,
        'ip' => $ip,
        'type' => $type,
        'min_gravite' => $min_g,
        'q' => $q,
    ],
]);
