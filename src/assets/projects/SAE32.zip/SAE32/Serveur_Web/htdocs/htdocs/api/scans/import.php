<?php
require __DIR__ . '/../../lib/db.php';
require __DIR__ . '/../../lib/nessus.php';

$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_method('POST');
    $body = read_json_body(false);

    $scan_id = isset($body['scan_id']) ? (int)$body['scan_id'] : 0;
    $replace = !empty($body['replace']);

    if ($scan_id <= 0) {
        json_response(['error' => 'scan_id est requis'], 400);
    }

    $stmt = $pdo->prepare("SELECT * FROM scan_sessions WHERE id = :id");
    $stmt->execute([':id' => $scan_id]);
    $session = $stmt->fetch();

    if (!$session) {
        json_response(['error' => 'scan_id inconnu'], 404);
    }

    // Récupération nessus_scan_id
    $nessus_scan_id = null;
    if (isset($session['nessus_scan_id']) && $session['nessus_scan_id'] !== null) {
        $nessus_scan_id = (int)$session['nessus_scan_id'];
    } else {
        // fallback: lire depuis note si possible
        if (isset($session['note']) && is_string($session['note'])) {
            if (preg_match('/nessus_scan_id=(\d+)/', $session['note'], $m)) {
                $nessus_scan_id = (int)$m[1];
            }
        }
    }

    if (!$nessus_scan_id) {
        json_response(['error' => 'Cette session ne contient pas de nessus_scan_id (scan Nessus non lié).'], 400);
    }

    if (!nessus_enabled()) {
        json_response(['error' => 'Nessus non configuré'], 400);
    }

    $pdo->beginTransaction();
    try {
        if ($replace) {
            $del = $pdo->prepare("DELETE FROM failles WHERE scan_id = :id");
            $del->execute([':id' => $scan_id]);
        }

        $xml = nessus_export_scan($nessus_scan_id);
        $items = nessus_parse_report($xml);

        $ins = $pdo->prepare("
            INSERT INTO failles (scan_id, ip, type, description, gravite)
            VALUES (:scan_id, :ip, :type, :description, :gravite)
        ");

        $inserted = 0;
        foreach ($items as $row) {
            $ins->execute([
                ':scan_id' => $scan_id,
                ':ip' => (string)$row['ip'],
                ':type' => (string)$row['type'],
                ':description' => (string)$row['description'],
                ':gravite' => (int)$row['gravite'],
            ]);
            $inserted++;
        }

        $pdo->commit();
        json_response(['scan_id' => $scan_id, 'inserted' => $inserted], 201);

    } catch (Throwable $e) {
        $pdo->rollBack();
        json_response(['error' => 'Erreur import Nessus', 'detail' => $e->getMessage()], 500);
    }
}

// GET: petit guide
require_method('GET');
json_response([
    'usage' => 'POST JSON {"scan_id":123,"replace":true}',
], 200);
