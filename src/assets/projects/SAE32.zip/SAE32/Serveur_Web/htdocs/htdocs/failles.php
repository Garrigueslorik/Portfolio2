<?php
require __DIR__ . '/lib/db.php';
require __DIR__ . '/lib/layout.php';

$pdo = db();
$cfg = app_config();

$scan_id = int_param('scan_id');
$ip = str_param('ip');
$type = str_param('type');
$min_g = int_param('min_gravite');
$q = str_param('q');

$limit = int_param('limit', $cfg['default_limit']);
if ($limit < 1) $limit = $cfg['default_limit'];
if ($limit > 2000) $limit = 2000;

$where = [];
$params = [];

if ($scan_id !== null) { $where[] = "f.scan_id = :scan_id"; $params[':scan_id'] = $scan_id; }
if ($ip) { $where[] = "f.ip = :ip"; $params[':ip'] = $ip; }
if ($type) { $where[] = "f.type = :type"; $params[':type'] = $type; }
if ($min_g !== null) { $where[] = "f.gravite >= :min_g"; $params[':min_g'] = $min_g; }
if ($q) {
    $where[] = "(f.description LIKE :q OR f.ip LIKE :q OR f.type LIKE :q)";
    $params[':q'] = '%' . $q . '%';
}

$sql = "
  SELECT f.id, f.scan_id, f.ip, f.type, f.description, f.gravite, f.created_at
  FROM failles f
";
if ($where) $sql .= " WHERE " . implode(" AND ", $where);
$sql .= " ORDER BY f.created_at DESC LIMIT " . (int)$limit;

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

render_header('Failles — Cyber Dashboard');
?>
  <h1>Failles</h1>
  <p class="lead">Recherche et filtres (dont par adresse IP).</p>

  <div class="card">
    <form method="get" class="toolbar">
      <div class="filters">
        <input name="scan_id" placeholder="scan_id" value="<?= h((string)($scan_id ?? '')) ?>" />
        <input name="ip" placeholder="ip (ex. 192.168.1.10)" value="<?= h((string)($ip ?? '')) ?>" />
        <input name="type" placeholder="type (ex. Port ouvert)" value="<?= h((string)($type ?? '')) ?>" />
        <input name="min_gravite" placeholder="gravité min" value="<?= h((string)($min_g ?? '')) ?>" />
        <input name="q" placeholder="recherche texte" value="<?= h((string)($q ?? '')) ?>" />
        <input name="limit" placeholder="limit" value="<?= h((string)$limit) ?>" />
      </div>
      <div style="display:flex; gap:10px; align-items:center;">
        <button type="submit">Filtrer</button>
        <a href="/failles.php" class="muted">Réinitialiser</a>
      </div>
    </form>

    <div style="overflow:auto; margin-top: 10px;">
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Scan</th>
            <th>IP</th>
            <th>Type</th>
            <th>Description</th>
            <th>Gravité</th>
            <th>Date</th>
          </tr>
        </thead>
        <tbody>
          <?php if (!$rows): ?>
            <tr><td colspan="7" class="muted">Aucune faille ne correspond aux filtres.</td></tr>
          <?php else: ?>
            <?php foreach ($rows as $r): ?>
              <?php
                $g = (int)$r['gravite'];
                $cls = $g >= 5 ? "badge--g5" : ($g >= 4 ? "badge--g4" : "badge--g3");
              ?>
              <tr>
                <td class="mono"><?= h((string)$r['id']) ?></td>
                <td class="mono"><a href="/scan.php?id=<?= urlencode((string)$r['scan_id']) ?>"><?= h((string)$r['scan_id']) ?></a></td>
                <td class="mono"><?= h((string)$r['ip']) ?></td>
                <td><?= h((string)$r['type']) ?></td>
                <td class="wrap"><?= h((string)$r['description']) ?></td>
                <td class="mono"><span class="badge <?= $cls ?>"><?= h((string)$g) ?></span></td>
                <td class="mono"><?= h((string)$r['created_at']) ?></td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
<?php render_footer(); ?>
