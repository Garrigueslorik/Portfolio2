<?php
function nessus_enabled(): bool {
    try {
        $cfg = app_config();
        if (!isset($cfg['nessus']) || !is_array($cfg['nessus'])) return false;

        $n = $cfg['nessus'];
        foreach (['base_url', 'access_key', 'secret_key'] as $k) {
            if (!isset($n[$k]) || trim((string)$n[$k]) === '') return false;
        }
        return true;
    } catch (Throwable $e) {
        return false;
    }
}

/**
 * lib/nessus.php
 *
 * Dépend de lib/db.php (app_config() doit exister).
 * Configuration attendue dans config/config.php :
 *   'nessus' => [
 *      'base_url'   => 'https://IP_NESSUS:8834',
 *      'access_key' => '...',
 *      'secret_key' => '...',
 *      'verify_ssl' => false, // si certificat auto-signé
 *   ]
 */

function nessus_cfg(): array {
    $cfg = app_config();
    if (!isset($cfg['nessus']) || !is_array($cfg['nessus'])) {
        throw new RuntimeException("Config manquante: section 'nessus' dans config/config.php");
    }
    $n = $cfg['nessus'];
    foreach (['base_url', 'access_key', 'secret_key'] as $k) {
        if (!isset($n[$k]) || trim((string)$n[$k]) === '') {
            throw new RuntimeException("Config Nessus invalide: clé manquante '$k'");
        }
    }
    return $n;
}

/**
 * Appel HTTP vers Nessus
 * - Retourne un array si JSON
 * - Retourne une string si non-JSON (XML/binaire)
 */
function nessus_request(string $method, string $path, $jsonBody = null, array $query = [], int $timeoutSec = 120) {
    $cfg = nessus_cfg();

    $base = rtrim((string)$cfg['base_url'], '/');
    $url  = $base . '/' . ltrim($path, '/');

    if (!empty($query)) {
        $url .= (str_contains($url, '?') ? '&' : '?') . http_build_query($query);
    }

    $headers = [
        'Accept: application/json',
        'X-ApiKeys: accessKey=' . $cfg['access_key'] . '; secretKey=' . $cfg['secret_key'],
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, strtoupper($method));
    curl_setopt($ch, CURLOPT_TIMEOUT, $timeoutSec);

    // SSL (souvent auto-signé sur un Nessus local)
    $verify = $cfg['verify_ssl'] ?? false;
    if (!$verify) {
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    } else {
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
    }

    if ($jsonBody !== null) {
        $payload = json_encode($jsonBody, JSON_UNESCAPED_UNICODE);
        if ($payload === false) {
            throw new RuntimeException("Erreur json_encode (Nessus body): " . json_last_error_msg());
        }
        $headers[] = 'Content-Type: application/json; charset=utf-8';
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    }

    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $raw = curl_exec($ch);
    if ($raw === false) {
        $err = curl_error($ch);
        curl_close($ch);
        throw new RuntimeException("Erreur cURL Nessus: " . $err);
    }

    $code  = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $ctype = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
    curl_close($ch);

    $isJson = stripos($ctype, 'application/json') !== false;

    if ($code < 200 || $code >= 300) {
        $detail = $isJson ? json_decode($raw, true) : $raw;
        $msg = is_string($detail) ? $detail : json_encode($detail, JSON_UNESCAPED_UNICODE);
        throw new RuntimeException("Nessus HTTP $code sur $path: " . $msg);
    }

    if ($isJson) {
        $decoded = json_decode($raw, true);
        if ($decoded === null && trim($raw) !== 'null') {
            throw new RuntimeException("Réponse JSON Nessus invalide sur $path");
        }
        return $decoded;
    }

    // xml / binaire / autre
    return $raw;
}

function nessus_list_templates(): array {
    // GET /editor/scan/templates
    $res = nessus_request('GET', '/editor/scan/templates', null, [], 120);
    // Selon versions, ça peut être ['templates'=>[...]]
    if (is_array($res) && isset($res['templates']) && is_array($res['templates'])) {
        return $res['templates'];
    }
    // sinon on renvoie brut
    return is_array($res) ? $res : [];
}

function nessus_create_scan(string $targets, string $name, ?string $templateUuid = null): array {
    $targets = trim($targets);
    $name = trim($name);

    if ($targets === '') {
        throw new RuntimeException("targets vide.");
    }
    if ($name === '') {
        $name = "Scan Nessus";
    }

    if (!$templateUuid) {
        $templates = nessus_list_templates();
        if (!$templates) {
            throw new RuntimeException("Impossible de récupérer les templates Nessus.");
        }
        $templateUuid = $templates[0]['uuid'] ?? null;
        if (!$templateUuid) {
            throw new RuntimeException("Template Nessus sans champ 'uuid'.");
        }
    }

    // POST /scans
    return nessus_request('POST', '/scans', [
        'uuid' => $templateUuid,
        'settings' => [
            'name' => $name,
            'enabled' => false,
            'text_targets' => $targets,
        ],
    ], [], 120);
}

function nessus_launch_scan(int $nessusScanId): string {
    if ($nessusScanId <= 0) {
        throw new RuntimeException("nessusScanId invalide.");
    }

    // POST /scans/{scan_id}/launch
    // Certaines versions acceptent un body vide; on envoie null pour éviter un JSON inutile.
    $res = nessus_request('POST', "/scans/$nessusScanId/launch", null, [], 120);
    return (string)($res['scan_uuid'] ?? '');
}

/**
 * Exporte un scan en format "nessus" (XML .nessus) et renvoie le XML.
 * Flux typique:
 *  - POST /scans/{id}/export -> { token: ... }
 *  - GET  /tokens/{token}/status (poll)
 *  - GET  /tokens/{token}/download -> xml
 */
function nessus_export_scan_nessus_xml(int $nessusScanId, int $maxWaitSec = 300): string {
    if ($nessusScanId <= 0) {
        throw new RuntimeException("nessusScanId invalide.");
    }

    $res = nessus_request('POST', "/scans/$nessusScanId/export", [
        'format' => 'nessus'
    ], [], 120);

    $token = $res['token'] ?? null;
    if (!$token) {
        throw new RuntimeException("Export Nessus: token manquant.");
    }

    $deadline = time() + max(10, $maxWaitSec);
    while (true) {
        $st = nessus_request('GET', "/tokens/$token/status", null, [], 120);
        $status = $st['status'] ?? null;

        if ($status === 'ready') {
            break;
        }
        if ($status === 'error') {
            throw new RuntimeException("Export Nessus en erreur (token=$token).");
        }
        if (time() > $deadline) {
            throw new RuntimeException("Timeout export Nessus (token=$token).");
        }

        usleep(500000); // 0.5s
    }

    $xml = nessus_request('GET', "/tokens/$token/download", null, [], 120);
    if (!is_string($xml) || $xml === '') {
        throw new RuntimeException("Download export Nessus vide.");
    }
    return $xml;
}

/**
 * Parse un XML .nessus et retourne un tableau de findings au format
 * [ ['ip'=>..., 'type'=>..., 'description'=>..., 'gravite'=>...], ... ]
 */
function parse_nessus_xml_findings(string $xml): array {
    $sx = @simplexml_load_string($xml);
    if ($sx === false) {
        throw new RuntimeException("XML .nessus invalide (simplexml_load_string a échoué).");
    }

    // Structure attendue : NessusClientData_v2 > Report > ReportHost > ReportItem
    $report = $sx->Report ?? null;
    if (!$report) {
        // parfois le root contient directement Report
        foreach ($sx->children() as $child) {
            if ($child->getName() === 'Report') {
                $report = $child;
                break;
            }
        }
    }

    if (!$report) {
        throw new RuntimeException("XML .nessus: noeud Report introuvable.");
    }

    $items = [];

    foreach ($report->ReportHost as $host) {
        $hostIp = (string)($host['name'] ?? '');

        // Cherche host-ip dans HostProperties
        if (isset($host->HostProperties)) {
            foreach ($host->HostProperties->tag as $tag) {
                if ((string)($tag['name'] ?? '') === 'host-ip') {
                    $hostIp = (string)$tag;
                    break;
                }
            }
        }

        foreach ($host->ReportItem as $ri) {
            $pluginName = (string)($ri['pluginName'] ?? '');
            $severity = (int)($ri['severity'] ?? 0); // 0..4

            // Mapping vers gravite 1..5
            $gravite = min(5, max(0, $severity + 1));

            $desc = trim((string)($ri->description ?? ''));
            $syn  = trim((string)($ri->synopsis ?? ''));
            $sol  = trim((string)($ri->solution ?? ''));
            $cvss = trim((string)($ri->cvss_base_score ?? ''));

            $full = "Plugin: " . ($pluginName !== '' ? $pluginName : 'Nessus Finding') . "\n";
            if ($cvss !== '') $full .= "CVSS: $cvss\n";
            if ($syn !== '')  $full .= "Synopsis: $syn\n";
            if ($desc !== '') $full .= "Description: $desc\n";
            if ($sol !== '')  $full .= "Solution: $sol\n";

            $items[] = [
                'ip' => $hostIp !== '' ? $hostIp : 'unknown',
                'type' => $pluginName !== '' ? $pluginName : 'Nessus Finding',
                'description' => trim($full),
                'gravite' => $gravite,
            ];
        }
    }

    return $items;
}
