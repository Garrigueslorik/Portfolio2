<?php
require __DIR__ . '/lib/db.php';
require __DIR__ . '/lib/layout.php';

$pdo = db();

$id = int_param('id');
if ($id === null) {
    header('Location: /');
    exit;
}

$scanStmt = $pdo->prepare("SELECT id, started_at, source, base_ip, note FROM scan_sessions WHERE id = :id");
$scanStmt->execute([':id' => $id]);
$scan = $scanStmt->fetch();

if (!$scan) {
    render_header('Scan introuvable');
    echo "<h1>Scan introuvable</h1><p class='lead'>Aucune session avec cet identifiant.</p>";
    render_footer();
    exit;
}

$ip = str_param('ip');
$type = str_param('type');
$min_g = int_param('min_gravite');
$q = str_param('q');

$limit = int_param('limit', 500);
if ($limit < 1) $limit = 500;
if ($limit > 5000) $limit = 5000;

$where = ["f.scan_id = :scan_id"];
$params = [':scan_id' => $id];

if ($ip) { $where[] = "f.ip = :ip"; $params[':ip'] = $ip; }
if ($type) { $where[] = "f.type = :type"; $params[':type'] = $type; }
if ($min_g !== null) { $where[] = "f.gravite >= :min_g"; $params[':min_g'] = $min_g; }
if ($q) { $where[] = "(f.description LIKE :q OR f.ip LIKE :q OR f.type LIKE :q)"; $params[':q'] = '%' . $q . '%'; }

$sql = "
  SELECT f.id, f.ip, f.type, f.description, f.gravite, f.created_at
  FROM failles f
  WHERE " . implode(" AND ", $where) . "
  ORDER BY f.gravite DESC, f.created_at DESC
  LIMIT " . (int)$limit;

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

$aggStmt = $pdo->prepare("SELECT COUNT(*) AS nb, COALESCE(MAX(gravite), 0) AS max_g FROM failles WHERE scan_id = :id");
$aggStmt->execute([':id' => $id]);
$agg = $aggStmt->fetch();

render_header('Détail scan #' . $id);
?>
  <h1>Scan #<?= h((string)$id) ?></h1>
  <p class="lead">Session du <span class="badge"><?= h((string)$scan['started_at']) ?></span> — <span class="badge">failles: <?= h((string)$agg['nb']) ?></span> — <span class="badge">gravité max: <?= h((string)$agg['max_g']) ?></span></p>

  <div class="grid cols-2">
    <div class="card">
      <h2 style="margin-top:0;">Métadonnées</h2>
      <div class="muted">Source: <span class="badge"><?= h((string)($scan['source'] ?? '')) ?></span></div>
      <div class="muted" style="margin-top:8px;">Base IP: <span class="badge"><?= h((string)($scan['base_ip'] ?? '—')) ?></span></div>
      <div class="muted" style="margin-top:8px;">Note: <?= h((string)($scan['note'] ?? '—')) ?></div>
    </div>

    <div class="card">
      <h2 style="margin-top:0;">API (JSON)</h2>
      <p class="muted">Exporter ce scan :</p>
      <div style="display:flex; gap:10px; flex-wrap:wrap;">
        <a class="badge" href="/api/failles/?scan_id=<?= urlencode((string)$id) ?>" target="_blank" rel="noreferrer">GET /api/failles/?scan_id=<?= h((string)$id) ?></a>
        <button type="button" data-copy="<?= h('/api/failles/?scan_id=' . $id) ?>">Copier</button>
      </div>
      <p class="muted" style="margin-top:12px;">Voir toutes les failles :</p>
      <a href="/failles.php?scan_id=<?= urlencode((string)$id) ?>">Ouvrir la liste filtrée</a>
    </div>
  </div>

  <div class="card" style="margin-top: 14px;">
    <form method="get" class="toolbar">
      <input type="hidden" name="id" value="<?= h((string)$id) ?>">
      <div class="filters">
        <input name="ip" placeholder="ip" value="<?= h((string)($ip ?? '')) ?>" />
        <input name="type" placeholder="type" value="<?= h((string)($type ?? '')) ?>" />
        <input name="min_gravite" placeholder="gravité min" value="<?= h((string)($min_g ?? '')) ?>" />
        <input name="q" placeholder="recherche texte" value="<?= h((string)($q ?? '')) ?>" />
        <input name="limit" placeholder="limit" value="<?= h((string)$limit) ?>" />
      </div>
      <div style="display:flex; gap:10px; align-items:center;">
        <button type="submit">Filtrer</button>
        <a href="/scan.php?id=<?= urlencode((string)$id) ?>" class="muted">Réinitialiser</a>
      </div>
    </form>

    <div style="overflow:auto; margin-top: 10px;">
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>IP</th>
            <th>Type</th>
            <th>Description</th>
            <th>Gravité</th>
            <th>Date</th>
          </tr>
        </thead>
        <tbody>
          <?php if (!$rows): ?>
            <tr><td colspan="6" class="muted">Aucune faille pour ce scan (ou filtres trop restrictifs).</td></tr>
          <?php else: ?>
            <?php foreach ($rows as $r): ?>
              <?php
                $g = (int)$r['gravite'];
                $cls = $g >= 5 ? "badge--g5" : ($g >= 4 ? "badge--g4" : "badge--g3");
              ?>
              <tr>
                <td class="mono"><?= h((string)$r['id']) ?></td>
                <td class="mono"><?= h((string)$r['ip']) ?></td>
                <td><?= h((string)$r['type']) ?></td>
                <td class="wrap"><?= h((string)$r['description']) ?></td>
                <td class="mono"><span class="badge <?= $cls ?>"><?= h((string)$g) ?></span></td>
                <td class="mono"><?= h((string)$r['created_at']) ?></td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
<?php render_footer(); ?>
