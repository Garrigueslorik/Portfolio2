<?php
require __DIR__ . '/../../lib/db.php';
require __DIR__ . '/../../lib/nessus.php';

$pdo = db();
$cfg = app_config();

/**
 * POST /api/scans/
 * Lance un scan Nessus (optionnel) et crée une session côté dashboard.
 *
 * Body JSON (objet):
 * {
 *   "targets": "10.11.10.0/24,10.11.10.40",
 *   "name": "Scan SAE",
 *   "template_uuid": "<uuid>"   // optionnel
 * }
 *
 * Réponse:
 * { "scan_id": 123, "nessus": { "scan_id": 12, "scan_uuid": "..." } }
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_method('POST');

    if (!nessus_enabled()) {
        json_response([
            'error' => 'Nessus non configuré',
            'hint' => 'Renseignez NESSUS_URL, NESSUS_ACCESS_KEY, NESSUS_SECRET_KEY dans config/config.php ou via variables d’environnement.'
        ], 400);
    }

    $body = read_json_body(false); // objet JSON

    $targets = isset($body['targets']) ? trim((string)$body['targets']) : '';
    $name = isset($body['name']) ? trim((string)$body['name']) : '';
    $template = isset($body['template_uuid']) ? trim((string)$body['template_uuid']) : '';

    if ($targets === '') {
        json_response(['error' => 'targets est requis (ex: "10.11.10.0/24,10.11.10.40")'], 400);
    }

    if ($name === '') {
        $name = 'SAE Scan ' . date('Y-m-d H:i:s');
    }

    if ($template === '') {
        // choix par défaut: "Basic Network Scan" si présent, sinon le 1er template
        $templates = nessus_list_templates();
        $found = '';
        foreach ($templates as $t) {
            $title = (string)($t['title'] ?? '');
            if (stripos($title, 'Basic Network Scan') !== false) {
                $found = (string)($t['uuid'] ?? '');
                break;
            }
        }
        if ($found === '' && $templates) {
            $found = (string)($templates[0]['uuid'] ?? '');
        }
        if ($found === '') {
            json_response(['error' => 'Impossible de déterminer un template Nessus (templates vides).'], 500);
        }
        $template = $found;
    }

    $pdo->beginTransaction();
    try {
        // 1) Crée la session côté dashboard
        $ins = $pdo->prepare("INSERT INTO scan_sessions (source, base_ip, note) VALUES (:source, :base_ip, :note)");
        $ins->execute([
            ':source' => 'nessus',
            ':base_ip' => $targets,
            ':note' => $name,
        ]);
        $sessionId = (int)$pdo->lastInsertId();

        // 2) Crée le scan Nessus + launch
        $created = nessus_create_scan($targets, $name, $template);

        // Selon Nessus, l'id est généralement dans created.scan.id
        $nessusScanId = null;
        if (is_array($created) && isset($created['scan']['id'])) $nessusScanId = (int)$created['scan']['id'];
        if (!$nessusScanId) {
            // fallback
            if (isset($created['id'])) $nessusScanId = (int)$created['id'];
        }
        if (!$nessusScanId) {
            throw new RuntimeException('Réponse create_scan inattendue: id manquant');
        }

        $scanUuid = nessus_launch_scan($nessusScanId);

        // 3) Sauvegarde des ids Nessus si colonnes présentes
        if (db_has_column($pdo, 'scan_sessions', 'nessus_scan_id') && db_has_column($pdo, 'scan_sessions', 'nessus_scan_uuid')) {
            $upd = $pdo->prepare("UPDATE scan_sessions SET nessus_scan_id = :sid, nessus_scan_uuid = :uuid WHERE id = :id");
            $upd->execute([':sid' => $nessusScanId, ':uuid' => $scanUuid, ':id' => $sessionId]);
        } else {
            // fallback: stocker dans note
            $note = $name . ' | nessus_scan_id=' . $nessusScanId . ' | scan_uuid=' . $scanUuid;
            $upd = $pdo->prepare("UPDATE scan_sessions SET note = :n WHERE id = :id");
            $upd->execute([':n' => $note, ':id' => $sessionId]);
        }

        $pdo->commit();

        json_response([
            'scan_id' => $sessionId,
            'nessus' => [
                'scan_id' => $nessusScanId,
                'scan_uuid' => $scanUuid,
                'template_uuid' => $template,
            ],
            'next' => [
                'import' => '/api/scans/import.php?scan_id=' . $sessionId
            ]
        ], 201);

    } catch (Throwable $e) {
        $pdo->rollBack();
        json_response(['error' => 'Erreur lancement Nessus', 'detail' => $e->getMessage()], 500);
    }
}

// GET (liste de sessions)
require_method('GET');

$limit = int_param('limit', 50);
if ($limit < 1) $limit = 50;
if ($limit > 500) $limit = 500;

$stmt = $pdo->prepare("
    SELECT
      s.id,
      s.started_at,
      s.source,
      s.base_ip,
      s.note,
      COALESCE(COUNT(f.id), 0) AS nb_failles,
      COALESCE(MAX(f.gravite), 0) AS max_gravite
    FROM scan_sessions s
    LEFT JOIN failles f ON f.scan_id = s.id
    GROUP BY s.id
    ORDER BY s.started_at DESC
    LIMIT :limit
");
$stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
$stmt->execute();
$scans = $stmt->fetchAll();

json_response([
    'items' => $scans,
    'limit' => $limit,
]);
