# SAE Cyber Dashboard (htdocs)

## 1) Installation (XAMPP / Apache + MySQL)

1. Copiez le contenu du dossier `htdocs/` dans votre `xampp/htdocs/`.
2. Démarrez **Apache** et **MySQL** dans XAMPP.
3. Ouvrez phpMyAdmin, puis importez `db/schema_mysql.sql`.
4. Ajustez `config/config.php` (ou utilisez des variables d’environnement).

Vérification rapide:
- http://localhost/status.php (connexion DB + tables)
- http://localhost/ (dashboard)
- http://localhost/api/scans/ (JSON)

## 2) API "failles" (Android/Java ou tests)

### POST /api/failles/
Body JSON = liste:
[
  {"ip":"192.168.0.1","type":"SQL Injection","description":"...","gravite":4}
]

Headers possibles:
- X-Source: java-scanner
- X-Base-IP: 10.11.10.0/24
- X-Note: commentaire

### GET /api/failles/?scan_id=123&min_gravite=4

## 3) Nessus (optionnel)

### Configuration
Dans `config/config.php` ou variables env:
- NESSUS_URL (ex: https://127.0.0.1:8834)
- NESSUS_ACCESS_KEY
- NESSUS_SECRET_KEY
- NESSUS_VERIFY_SSL (1/true si certificat valide)

### Templates
GET /api/scans/templates.php

### Lancer un scan
POST /api/scans/
{
  "targets": "10.11.10.0/24,10.11.10.40",
  "name": "Scan SAE",
  "template_uuid": "<uuid optionnel>"
}

### Importer les résultats dans la DB
POST /api/scans/import.php
{
  "scan_id": 123,
  "replace": true
}

Ensuite:
- http://localhost/ (le scan apparaît et les failles sont visibles)
