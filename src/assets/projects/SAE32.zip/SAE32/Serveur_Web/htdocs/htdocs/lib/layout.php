<?php
function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

function render_header(string $title): void {
    $t = h($title);
    echo "<!doctype html><html lang='fr'><head>";
    echo "<meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>";
    echo "<title>{$t}</title>";
    echo "<link rel='stylesheet' href='/assets/style.css'>";
    echo "</head><body>";
    echo "<header class='topbar'><div class='container'>";
    echo "<div class='brand'><span class='brand__title'>SAÉ 3.02</span><span class='brand__sep'>—</span><span class='brand__sub'>Cyber Dashboard</span></div>";
    echo "<nav class='nav'><a href='/'>Accueil</a><a href='/failles.php'>Failles</a><a href='/status.php'>Statut DB</a><a href='/api/scans/'>API Scans</a><a href='/api/failles/'>API Failles</a></nav>";
    echo "</div></header>";
    echo "<main class='container'>";
}

function render_footer(): void {
    $year = date('Y');
    echo "</main>";
    echo "<footer class='footer'><div class='container'>";
    echo "<div>SAÉ 3.02 — Site web cyber-sécurité — {$year}</div>";
    echo "</div></footer>";
    echo "<script src='/assets/app.js' defer></script>";
    echo "</body></html>";
}
