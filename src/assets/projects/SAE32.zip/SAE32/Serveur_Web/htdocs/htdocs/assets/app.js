(function(){
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && e.target && e.target.matches('input')) {
      const form = e.target.closest('form');
      if (form) form.submit();
    }
  });

  document.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-copy]');
    if (!btn) return;
    const value = btn.getAttribute('data-copy') || '';
    if (!navigator.clipboard) return;
    navigator.clipboard.writeText(value).then(()=>{
      btn.textContent = 'Copié';
      setTimeout(()=> btn.textContent = 'Copier', 900);
    }).catch(()=>{});
  });
})();
