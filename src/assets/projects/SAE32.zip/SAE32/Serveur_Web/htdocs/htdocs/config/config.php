<?php
// Configuration (DB + options)
// Surcharge possible via variables d'environnement:
//   DB_HOST, DB_NAME, DB_USER, DB_PASS, DB_CHARSET, DEFAULT_LIMIT
//   APP_DEBUG (1/true pour activer les détails d'erreur côté API)
//   NESSUS_URL, NESSUS_ACCESS_KEY, NESSUS_SECRET_KEY, NESSUS_VERIFY_SSL (1/true)

$bool = function($v, $default = false) {
    if ($v === false || $v === null || $v === '') return $default;
    return filter_var($v, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE) ?? $default;
};

$int = function($v, $default) {
    if ($v === false || $v === null || $v === '') return $default;
    $n = filter_var($v, FILTER_VALIDATE_INT);
    return ($n === false) ? $default : (int)$n;
};

return [
    'debug' => $bool(getenv('APP_DEBUG'), false),

    'db' => [
        'host'    => getenv('DB_HOST') ?: 'localhost',
        'name'    => getenv('DB_NAME') ?: 'sae_cyber',
        'user'    => getenv('DB_USER') ?: 'root',
        'pass'    => getenv('DB_PASS') ?: '',
        'charset' => getenv('DB_CHARSET') ?: 'utf8mb4',
    ],

    'default_limit' => $int(getenv('DEFAULT_LIMIT'), 200),

    // Intégration Nessus (optionnelle)
    // Base URL typique : https://<nessus-host>:8834
    'nessus' => [
        'base_url'    => getenv('NESSUS_URL') ?: 'https://localhost:8834',
        'access_key'  => getenv('NESSUS_ACCESS_KEY') ?: '',
        'secret_key'  => getenv('NESSUS_SECRET_KEY') ?: '',
        // Si Nessus utilise un certificat auto-signé, mettre NESSUS_VERIFY_SSL=0 (défaut).
        'verify_ssl'  => $bool(getenv('NESSUS_VERIFY_SSL'), false),
        // Timeout global cURL (secondes)
        'timeout'     => $int(getenv('NESSUS_TIMEOUT'), 30),
        // Timeout d'attente export token (secondes)
        'export_wait' => $int(getenv('NESSUS_EXPORT_WAIT'), 180),
    ],
];
