<?php

function app_config(): array {
    static $cfg = null;
    if ($cfg === null) {
        $cfg = require __DIR__ . '/../config/config.php';
    }
    return $cfg;
}

function app_debug(): bool {
    $cfg = app_config();
    return !empty($cfg['debug']);
}

function db(): PDO {
    static $pdo = null;
    if ($pdo !== null) return $pdo;

    $cfg = app_config()['db'];

    // Connexion sans port (port MySQL par défaut: 3306)
    $dsn = sprintf(
        'mysql:host=%s;dbname=%s;charset=%s',
        $cfg['host'],
        $cfg['name'],
        $cfg['charset']
    );

    $pdo = new PDO($dsn, $cfg['user'], $cfg['pass'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    return $pdo;
}

function json_response($data, int $status = 200): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Source, X-Base-IP, X-Note');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function require_method(string $method): void {
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Source, X-Base-IP, X-Note');
        http_response_code(204);
        exit;
    }
    if ($_SERVER['REQUEST_METHOD'] !== $method) {
        json_response(['error' => 'Method not allowed'], 405);
    }
}

/**
 * Lit et décode le JSON du body.
 * - $expect_list = true : exige un tableau JSON "liste" (ex: [ {...}, {...} ])
 * - $expect_list = false: accepte un objet JSON (ex: { "targets": "..." })
 */
function read_json_body(bool $expect_list): array {
    $raw = file_get_contents('php://input');
    if ($raw === false) $raw = '';

    try {
        $data = json_decode($raw, true, 512, JSON_THROW_ON_ERROR);
    } catch (JsonException $e) {
        $payload = ['error' => 'JSON invalide', 'json_error' => $e->getMessage()];
        if (app_debug()) {
            $payload['raw_len'] = strlen($raw);
            $payload['raw_preview'] = substr($raw, 0, 300);
        }
        json_response($payload, 400);
    }

    if (!is_array($data)) {
        $payload = ['error' => 'JSON invalide: un tableau/objet est attendu'];
        if (app_debug()) {
            $payload['type'] = gettype($data);
            $payload['raw_len'] = strlen($raw);
            $payload['raw_preview'] = substr($raw, 0, 300);
        }
        json_response($payload, 400);
    }

    if ($expect_list && function_exists('array_is_list')) {
        if (!array_is_list($data)) {
            json_response(['error' => 'JSON invalide: une liste est attendue (ex: [ {...}, {...} ])'], 400);
        }
    }

    return $data;
}

function int_param(string $name, ?int $default = null): ?int {
    if (!isset($_GET[$name]) || $_GET[$name] === '') return $default;
    $v = filter_var($_GET[$name], FILTER_VALIDATE_INT);
    return ($v === false) ? $default : (int)$v;
}

function str_param(string $name, ?string $default = null): ?string {
    if (!isset($_GET[$name]) || $_GET[$name] === '') return $default;
    return trim((string)$_GET[$name]);
}

/**
 * Vérifie si une colonne existe (utile pour migrations non appliquées).
 */
function db_has_column(PDO $pdo, string $table, string $column): bool {
    $cfg = app_config()['db'];
    $sql = "SELECT COUNT(*) AS c
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = :db
              AND TABLE_NAME = :t
              AND COLUMN_NAME = :c";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':db' => $cfg['name'], ':t' => $table, ':c' => $column]);
    return ((int)($stmt->fetch()['c'] ?? 0)) > 0;
}
