<?php
require __DIR__ . '/../../lib/db.php';
require __DIR__ . '/../../lib/nessus.php';

require_method('GET');

if (!nessus_enabled()) {
    json_response([
        'error' => 'Nessus non configuré',
        'hint' => 'Renseignez NESSUS_URL, NESSUS_ACCESS_KEY, NESSUS_SECRET_KEY'
    ], 400);
}

try {
    $templates = nessus_list_templates();
    json_response(['templates' => $templates], 200);
} catch (Throwable $e) {
    json_response(['error' => 'Erreur Nessus', 'detail' => $e->getMessage()], 500);
}
