-- Schéma MySQL/MariaDB pour le projet SAE (dashboard + API)
-- Base: sae_cyber
-- Tables:
--   scan_sessions : une session de scan (source = java-scanner ou nessus)
--   failles       : failles associées à une session
--
-- Note: COLLATE utf8mb4_unicode_ci est compatible MySQL 5.7/8+ et MariaDB.

CREATE DATABASE IF NOT EXISTS sae_cyber
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE sae_cyber;

CREATE TABLE IF NOT EXISTS scan_sessions (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  started_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  source VARCHAR(50) NOT NULL DEFAULT 'java-scanner',
  base_ip VARCHAR(255) NULL,
  note VARCHAR(255) NULL,

  -- champs optionnels (si vous utilisez Nessus via /api/scans POST)
  nessus_scan_id BIGINT UNSIGNED NULL,
  nessus_scan_uuid VARCHAR(64) NULL,

  PRIMARY KEY (id),
  INDEX idx_started_at (started_at),
  INDEX idx_source (source)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS failles (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  scan_id BIGINT UNSIGNED NOT NULL,
  ip VARCHAR(45) NOT NULL,
  type VARCHAR(150) NOT NULL,
  description TEXT NOT NULL,
  gravite INT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),

  CONSTRAINT fk_failles_scan
    FOREIGN KEY (scan_id) REFERENCES scan_sessions(id)
    ON DELETE CASCADE
    ON UPDATE RESTRICT,

  INDEX idx_scan (scan_id),
  INDEX idx_ip_type (ip, type),
  INDEX idx_gravite (gravite),
  INDEX idx_created_at (created_at)
) ENGINE=InnoDB;
