package com.example.flightagency;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * Test minimal : vérifie que le contexte Spring démarre.
 */
@SpringBootTest
class SmokeTest {

    @Test
    void contextLoads() {
        // Rien à faire : si ça démarre, le test passe.
    }
}
