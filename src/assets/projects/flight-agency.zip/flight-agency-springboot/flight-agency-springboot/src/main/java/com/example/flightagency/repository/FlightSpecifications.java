package com.example.flightagency.repository;

import com.example.flightagency.model.Flight;
import org.springframework.data.jpa.domain.Specification;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Spécifications JPA pour filtrer les vols.
 * 
 * Utilisation : FlightRepository.findAll(Specification)
 */
public final class FlightSpecifications {

    private FlightSpecifications() {}

    public static Specification<Flight> fromCity(String from) {
        return (root, query, cb) -> from == null || from.isBlank()
                ? cb.conjunction()
                : cb.equal(cb.lower(root.get("departureCity")), from.trim().toLowerCase());
    }

    public static Specification<Flight> toCity(String to) {
        return (root, query, cb) -> to == null || to.isBlank()
                ? cb.conjunction()
                : cb.equal(cb.lower(root.get("arrivalCity")), to.trim().toLowerCase());
    }

    /**
     * Filtre par date (jour) : ex. 2026-03-01 => tous les vols dont departureTime est ce jour-là.
     */
    public static Specification<Flight> departureDate(LocalDate date) {
        return (root, query, cb) -> {
            if (date == null) {
                return cb.conjunction();
            }
            // On compare sur l'intervalle [date 00:00, date+1 00:00)
            var start = date.atStartOfDay();
            var end = date.plusDays(1).atStartOfDay();
            return cb.and(
                    cb.greaterThanOrEqualTo(root.get("departureTime"), start),
                    cb.lessThan(root.get("departureTime"), end)
            );
        };
    }

    public static Specification<Flight> maxPrice(BigDecimal maxPrice) {
        return (root, query, cb) -> maxPrice == null
                ? cb.conjunction()
                : cb.lessThanOrEqualTo(root.get("price"), maxPrice);
    }
}
