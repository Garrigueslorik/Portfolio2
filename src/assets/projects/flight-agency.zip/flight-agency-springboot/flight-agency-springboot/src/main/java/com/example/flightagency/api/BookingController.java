package com.example.flightagency.api;

import com.example.flightagency.dto.CreateBookingRequest;
import com.example.flightagency.model.Booking;
import com.example.flightagency.service.BookingService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Contrôleur REST pour les réservations.
 */
@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    private final BookingService bookingService;

    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }

    @PostMapping
    public Booking create(@Valid @RequestBody CreateBookingRequest req) {
        return bookingService.create(req);
    }

    @GetMapping("/{id}")
    public Booking getById(@PathVariable Long id) {
        return bookingService.getById(id);
    }

    /**
     * Liste des réservations d'un client.
     * Exemple : /api/bookings?customerId=1
     */
    @GetMapping
    public List<Booking> listByCustomer(@RequestParam Long customerId) {
        return bookingService.listByCustomer(customerId);
    }

    @DeleteMapping("/{id}")
    public Booking cancel(@PathVariable Long id) {
        return bookingService.cancel(id);
    }
}
