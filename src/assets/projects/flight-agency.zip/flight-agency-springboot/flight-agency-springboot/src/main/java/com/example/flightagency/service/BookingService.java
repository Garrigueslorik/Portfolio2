package com.example.flightagency.service;

import com.example.flightagency.dto.CreateBookingRequest;
import com.example.flightagency.model.Booking;
import com.example.flightagency.model.Customer;
import com.example.flightagency.model.Flight;
import com.example.flightagency.repository.BookingRepository;
import com.example.flightagency.repository.CustomerRepository;
import com.example.flightagency.repository.FlightRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Service métier des réservations.
 * 
 * Règle : réserver X places décrémente seatsAvailable du vol.
 * Annuler : on repasse le status à CANCELLED et on recrédite les places.
 */
@Service
public class BookingService {

    private final BookingRepository bookingRepository;
    private final CustomerRepository customerRepository;
    private final FlightRepository flightRepository;

    public BookingService(BookingRepository bookingRepository,
                          CustomerRepository customerRepository,
                          FlightRepository flightRepository) {
        this.bookingRepository = bookingRepository;
        this.customerRepository = customerRepository;
        this.flightRepository = flightRepository;
    }

    @Transactional
    public Booking create(CreateBookingRequest req) {
        Customer customer = customerRepository.findById(req.getCustomerId())
                .orElseThrow(() -> new NotFoundException("Client introuvable (id=" + req.getCustomerId() + ")"));

        Flight flight = flightRepository.findById(req.getFlightId())
                .orElseThrow(() -> new NotFoundException("Vol introuvable (id=" + req.getFlightId() + ")"));

        int seats = req.getSeats();
        if (seats <= 0) {
            throw new BadRequestException("Le nombre de places doit être > 0");
        }
        if (flight.getSeatsAvailable() < seats) {
            throw new BadRequestException("Pas assez de places disponibles. Restant=" + flight.getSeatsAvailable());
        }

        // Décrément des places
        flight.setSeatsAvailable(flight.getSeatsAvailable() - seats);
        flightRepository.save(flight);

        Booking booking = new Booking(customer, flight, seats);
        return bookingRepository.save(booking);
    }

    @Transactional(readOnly = true)
    public Booking getById(Long id) {
        return bookingRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Réservation introuvable (id=" + id + ")"));
    }

    @Transactional(readOnly = true)
    public List<Booking> listByCustomer(Long customerId) {
        return bookingRepository.findByCustomerId(customerId);
    }

    @Transactional
    public Booking cancel(Long bookingId) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new NotFoundException("Réservation introuvable (id=" + bookingId + ")"));

        if (booking.getStatus() == Booking.Status.CANCELLED) {
            return booking; // idempotent : annuler 2 fois ne change rien
        }

        // Recrédit des places sur le vol
        Flight flight = booking.getFlight();
        flight.setSeatsAvailable(flight.getSeatsAvailable() + booking.getSeatsBooked());
        flightRepository.save(flight);

        booking.setStatus(Booking.Status.CANCELLED);
        return bookingRepository.save(booking);
    }
}
