package com.example.flightagency.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

/**
 * DTO pour réserver : associer un client à un vol.
 */
public class CreateBookingRequest {

    @NotNull
    private Long customerId;

    @NotNull
    private Long flightId;

    @Min(1)
    private int seats;

    public Long getCustomerId() { return customerId; }
    public void setCustomerId(Long customerId) { this.customerId = customerId; }

    public Long getFlightId() { return flightId; }
    public void setFlightId(Long flightId) { this.flightId = flightId; }

    public int getSeats() { return seats; }
    public void setSeats(int seats) { this.seats = seats; }
}
