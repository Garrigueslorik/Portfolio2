package com.example.flightagency.service;

/**
 * Exception "404 Not Found" côté API.
 */
public class NotFoundException extends RuntimeException {
    public NotFoundException(String message) {
        super(message);
    }
}
