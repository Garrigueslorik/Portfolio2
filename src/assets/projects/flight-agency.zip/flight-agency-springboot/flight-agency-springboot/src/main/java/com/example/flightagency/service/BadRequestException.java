package com.example.flightagency.service;

/**
 * Exception "400 Bad Request" côté API.
 */
public class BadRequestException extends RuntimeException {
    public BadRequestException(String message) {
        super(message);
    }
}
