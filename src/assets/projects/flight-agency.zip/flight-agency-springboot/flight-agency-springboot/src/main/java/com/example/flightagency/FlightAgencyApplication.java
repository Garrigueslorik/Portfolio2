package com.example.flightagency;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Point d'entrée de l'application Spring Boot.
 * 
 * L'application expose une API REST pour :
 * - gérer des vols (Flights)
 * - gérer des clients (Customers)
 * - créer/annuler des réservations (Bookings)
 */
@SpringBootApplication
public class FlightAgencyApplication {

    public static void main(String[] args) {
        SpringApplication.run(FlightAgencyApplication.class, args);
    }
}
