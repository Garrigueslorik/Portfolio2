-- Données d'exemple (chargées au démarrage)

INSERT INTO customers(full_name, email) VALUES
  ('Lori K', 'lori@example.com'),
  ('Alex Martin', 'alex.martin@example.com');

INSERT INTO flights(departure_city, arrival_city, departure_time, airline, price, seats_total, seats_available) VALUES
  ('Paris', 'Rome',  '2026-03-01T09:15:00', 'Air Exemple', 149.90, 180, 180),
  ('Paris', 'Berlin','2026-03-02T14:00:00', 'Sky Demo',    99.00,  120, 120),
  ('Lyon',  'Madrid','2026-03-05T07:30:00', 'Air Exemple', 129.50, 150, 150),
  ('Nice',  'Paris', '2026-03-06T18:45:00', 'Sky Demo',     89.99,  90,  90);
