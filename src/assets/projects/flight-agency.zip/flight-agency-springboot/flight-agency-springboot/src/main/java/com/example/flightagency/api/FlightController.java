package com.example.flightagency.api;

import com.example.flightagency.dto.CreateFlightRequest;
import com.example.flightagency.model.Flight;
import com.example.flightagency.service.FlightService;
import jakarta.validation.Valid;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * Contrôleur REST pour les vols.
 */
@RestController
@RequestMapping("/api/flights")
public class FlightController {

    private final FlightService flightService;

    public FlightController(FlightService flightService) {
        this.flightService = flightService;
    }

    /**
     * Recherche / listing de vols.
     * Exemples :
     * - /api/flights?from=Paris&to=Rome
     * - /api/flights?date=2026-03-01
     * - /api/flights?maxPrice=199.99
     */
    @GetMapping
    public List<Flight> search(
            @RequestParam(required = false) String from,
            @RequestParam(required = false) String to,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
            @RequestParam(required = false) BigDecimal maxPrice
    ) {
        return flightService.search(from, to, date, maxPrice);
    }

    @GetMapping("/<built-in function id>")
    public Flight getById(@PathVariable Long id) {
        return flightService.getById(id);
    }

    /**
     * Création d'un vol (endpoint utile pour une démo).
     */
    @PostMapping
    public Flight create(@Valid @RequestBody CreateFlightRequest req) {
        return flightService.create(req);
    }

    @DeleteMapping("/<built-in function id>")
    public void delete(@PathVariable Long id) {
        flightService.delete(id);
    }
}
