package com.example.flightagency.repository;

import com.example.flightagency.model.Flight;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

/**
 * Repository JPA pour Flight.
 * 
 * On active aussi les Specifications pour faire des filtres (from/to/date/maxPrice).
 */
public interface FlightRepository extends JpaRepository<Flight, Long>, JpaSpecificationExecutor<Flight> {
}
