package com.example.flightagency.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * Entité "Réservation".
 * 
 * Une réservation relie un client à un vol, avec un nombre de places.
 */
@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Table(name = "bookings")
public class Booking {

    public enum Status {
        CONFIRMED,
        CANCELLED
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Many bookings can reference the same customer
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;

    // Many bookings can reference the same flight
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "flight_id", nullable = false)
    private Flight flight;

    @Column(name="seats_booked", nullable=false)
    private int seatsBooked;

    @Enumerated(EnumType.STRING)
    @Column(name="status", nullable=false, length=20)
    private Status status;

    @Column(name="created_at", nullable=false)
    private LocalDateTime createdAt;

    protected Booking() {
        // JPA
    }

    public Booking(Customer customer, Flight flight, int seatsBooked) {
        this.customer = customer;
        this.flight = flight;
        this.seatsBooked = seatsBooked;
        this.status = Status.CONFIRMED;
        this.createdAt = LocalDateTime.now();
    }

    public Long getId() { return id; }

    public Customer getCustomer() { return customer; }
    public Flight getFlight() { return flight; }

    public int getSeatsBooked() { return seatsBooked; }
    public void setSeatsBooked(int seatsBooked) { this.seatsBooked = seatsBooked; }

    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }

    public LocalDateTime getCreatedAt() { return createdAt; }
}
