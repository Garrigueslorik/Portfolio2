package com.example.flightagency.service;

import com.example.flightagency.dto.CreateCustomerRequest;
import com.example.flightagency.model.Customer;
import com.example.flightagency.repository.CustomerRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Service métier pour les clients.
 */
@Service
public class CustomerService {

    private final CustomerRepository customerRepository;

    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    @Transactional(readOnly = true)
    public List<Customer> list() {
        return customerRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Customer getById(Long id) {
        return customerRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Client introuvable (id=" + id + ")"));
    }

    @Transactional
    public Customer create(CreateCustomerRequest req) {
        // Règle métier : email unique
        customerRepository.findByEmail(req.getEmail()).ifPresent(existing -> {
            throw new BadRequestException("Email déjà utilisé : " + req.getEmail());
        });

        Customer c = new Customer(req.getFullName(), req.getEmail());
        return customerRepository.save(c);
    }
}
