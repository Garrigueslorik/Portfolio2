package com.example.flightagency.api;

import java.time.LocalDateTime;

/**
 * Format d'erreur JSON retourné par l'API.
 */
public class ApiError {
    private final String message;
    private final String path;
    private final LocalDateTime timestamp;

    public ApiError(String message, String path) {
        this.message = message;
        this.path = path;
        this.timestamp = LocalDateTime.now();
    }

    public String getMessage() { return message; }
    public String getPath() { return path; }
    public LocalDateTime getTimestamp() { return timestamp; }
}
