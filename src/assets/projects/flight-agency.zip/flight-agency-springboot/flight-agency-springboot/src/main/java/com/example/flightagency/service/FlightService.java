package com.example.flightagency.service;

import com.example.flightagency.dto.CreateFlightRequest;
import com.example.flightagency.model.Flight;
import com.example.flightagency.repository.FlightRepository;
import com.example.flightagency.repository.FlightSpecifications;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * Service métier pour les vols.
 * 
 * Le service contient la logique (validation métier, filtres, etc.).
 */
@Service
public class FlightService {

    private final FlightRepository flightRepository;

    public FlightService(FlightRepository flightRepository) {
        this.flightRepository = flightRepository;
    }

    @Transactional(readOnly = true)
    public List<Flight> search(String from, String to, LocalDate date, BigDecimal maxPrice) {
        Specification<Flight> spec = Specification
                .where(FlightSpecifications.fromCity(from))
                .and(FlightSpecifications.toCity(to))
                .and(FlightSpecifications.departureDate(date))
                .and(FlightSpecifications.maxPrice(maxPrice));

        return flightRepository.findAll(spec);
    }

    @Transactional(readOnly = true)
    public Flight getById(Long id) {
        return flightRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Vol introuvable (id=" + id + ")"));
    }

    @Transactional
    public Flight create(CreateFlightRequest req) {
        // Règle métier : seatsAvailable ne peut pas dépasser seatsTotal.
        if (req.getSeatsAvailable() > req.getSeatsTotal()) {
            throw new BadRequestException("seatsAvailable ne peut pas être > seatsTotal");
        }

        Flight flight = new Flight(
                req.getDepartureCity(),
                req.getArrivalCity(),
                req.getDepartureTime(),
                req.getAirline(),
                req.getPrice(),
                req.getSeatsTotal(),
                req.getSeatsAvailable()
        );
        return flightRepository.save(flight);
    }

    @Transactional
    public void delete(Long id) {
        if (!flightRepository.existsById(id)) {
            throw new NotFoundException("Vol introuvable (id=" + id + ")");
        }
        flightRepository.deleteById(id);
    }
}
