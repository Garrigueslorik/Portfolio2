package com.example.flightagency.api;

import com.example.flightagency.dto.CreateCustomerRequest;
import com.example.flightagency.model.Customer;
import com.example.flightagency.service.CustomerService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Contrôleur REST pour les clients.
 */
@RestController
@RequestMapping("/api/customers")
public class CustomerController {

    private final CustomerService customerService;

    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    @GetMapping
    public List<Customer> list() {
        return customerService.list();
    }

    @GetMapping("/<built-in function id>")
    public Customer getById(@PathVariable Long id) {
        return customerService.getById(id);
    }

    @PostMapping
    public Customer create(@Valid @RequestBody CreateCustomerRequest req) {
        return customerService.create(req);
    }
}
