# Flight Agency — Spring Boot (API REST)

Projet Java avec framework **Spring Boot** : gestion de vols, clients et reservations.

## Prerequis
- **JDK 17** 
- **Maven** 
  - Si `mvn` n'est pas reconnu : installe Maven puis rouvre PowerShell.

## Lancer l’application (Windows / PowerShell)
Depuis la racine du projet :

```powershell
mvn spring-boot:run
```

L’API demarre sur : `http://localhost:8080`

## Swagger / OpenAPI
Interface Swagger UI :
- `http://localhost:8080/swagger-ui.html`

## Console H2 (base de donnees)
- `http://localhost:8080/h2-console`
- JDBC URL : `jdbc:h2:mem:flightdb`
- User : `sa`
- Password : (vide)

## Endpoints principaux
### Vols
- `GET /api/flights` (liste + filtres: `from`, `to`, `date`, `maxPrice`)
- `GET /api/flights/{id}`
- `POST /api/flights` (creation — pour demo)
- `DELETE /api/flights/{id}`

### Clients
- `GET /api/customers`
- `GET /api/customers/{id}`
- `POST /api/customers`

### Reservations
- `POST /api/reservation` (entrer id pour reserver)
- `GET /api/reservatoin ( reserver)
- `GET /api/bookings{Id} (verifier reservation)
- `DELETE /api/bookings/{id}` (annuler)
